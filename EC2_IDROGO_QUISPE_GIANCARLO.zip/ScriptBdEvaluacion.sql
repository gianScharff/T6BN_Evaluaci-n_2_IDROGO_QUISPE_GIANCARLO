CREATE DATABASE  IF NOT EXISTS `bd_evaluacion2` ;
USE `bd_evaluacion2`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_evaluacion2
-- ------------------------------------------------------
-- Server version	5.6.23-log

--
-- Table structure for table `tb_viaje`
--

DROP TABLE IF EXISTS `tb_viaje`;

CREATE TABLE `tb_viaje` (
  `IdViaje` int(11) NOT NULL AUTO_INCREMENT,
  `conductor` varchar(45) DEFAULT NULL,
  `placa` varchar(45) DEFAULT NULL,
  `cantidad_boletos` int(11) DEFAULT NULL,
  `precio_viaje` double DEFAULT NULL,
  PRIMARY KEY (`IdViaje`)
);

--
-- Dumping data for table `tb_viaje`
--

LOCK TABLES `tb_viaje` WRITE;
/*!40000 ALTER TABLE `tb_viaje` DISABLE KEYS */;
INSERT INTO `tb_viaje` VALUES (7,'gian carlo idrogo ','xyz-rq',20,30),(8,'alex belleza','SUSS-AR',5,40),(9,'conductor3','uyzaa-aa',50,70);
/*!40000 ALTER TABLE `tb_viaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bd_evaluacion2'
--

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listAllViaje`(prec1 double, prec2 double)
BEGIN
	select * from tb_viaje where precio_viaje>=prec1 and precio_viaje <= prec2;
END ;;
DELIMITER ;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_saveViaje`(conductor varchar(45),placa varchar(45),cantidad_boletos int , precio_viaje double)
BEGIN
 insert into tb_viaje values(null,conductor,placa,cantidad_boletos,precio_viaje);
END ;;

-- Dump completed on 2020-06-02 10:07:49
